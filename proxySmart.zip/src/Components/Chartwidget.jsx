import { useEffect } from "react";
import {Helmet} from "react-helmet";
import { Chart,registerables} from 'Chart.js' 


window.Chart = Chart; 
Chart.register(...registerables);
export default function Chartwidget() {

    

    useEffect(() => {
 
    
        let chart = new Chart(document.getElementById("myChart"), {

            
            type: "line",
            data: {
                labels: ["January", "February", "March", "April", "May", "June", "July", "Aug", "Sep","Oct", "Nov", "Dec"],
                datasets: [
                    {
                        label: "12 dec 2023",
                        borderColor: "#4A5568",
                        data: [100, 4300, 620, 300, 10000, 600, 11230, 300, 200, 200, 10000, 11100],
                        fill: false,
                        pointBackgroundColor: "#4A5568",
                        borderWidth: "3",
                        pointBorderWidth: "4",
                        pointHoverRadius: "0",
                        pointHoverBorderWidth: "8",
                        pointHoverBorderColor: "rgb(74,85,104,0.2)",
                    },
                ],
            },
            options: {
                legend: {
                    position: false,
                },
                scales: {
                    y: {
                            gridLines: {
                                display: false,
                            },
                            display: false,
                        },
                    
                    
                },
            },
            
        });
   return()=>{
    if(chart){
        chart.destroy()
    }
   }
        
      
    },[]
    );
    return (
        <>
            <Helmet>
                <script src="https://cdn.jsdelivr.net/npm/chart.js@2.8.0"></script>
                <script defer src="https://cdn.tuk.dev/dev/light-dark-switch.js">
                
                </script>
            </Helmet>
            <div className="flex items-center justify-center py-2 px-4 ">
                <div className="w-[25rem] md:w-[28rem] p-3 md:p-0 mt-5 md:mt-0 md:ml-[4rem] ">
                    <div className="flex flex-col justify-between h-full">
                        <div>
                            <canvas id="myChart" width={1025} height={400} />
                        </div>
                    </div>
                </div>
            </div>
        </>
    );
}
