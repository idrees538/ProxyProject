import React from "react";
import bar from "../images/bars.png";
import "./Scroll.css";
import logo from "../images/logo.png";
import Footer from "../Components/Footer";
import UDrawer from "../Components/UDrawer";
import faqexpand from "../images/faqlogo.png";

function FAQ() {
  const [isOpens, setIsOpen] = React.useState(false);
  return (
    <div>
      <div className=" bg-[linear-gradient(135deg,_rgba(87,120,117,1)_3%,_rgba(74,82,89,1)_30%,_rgba(74,82,89,1)_69%,_rgba(83,107,108,1)_98%)]">
        {/* Nav */}
        <div className="flex justify-between p-5 md:pl-20 md:pr-20  w-full h-[5rem] bg-[#000300]">
          <div className=" flex ">
            <img
              onClick={setIsOpen}
              className=" h-[2rem] w-[2rem] mt-1 lg:hidden"
              src={bar}
              alt=""
            />
            <img className=" w-[7rem] h-[3rem]" src={logo} alt="" />
          </div>
          <div className=" hidden md:flex">
            <ul className="mt-2 flex gap-2 md:gap-12 text-sm text-white font-bold">
              <li className=" mt-1">Home</li>
              <li className=" mt-1">Login</li>
              <button className=" bg-[#00B795] text-black text-sm rounded-md px-2 py-1 md:px-4 md:py-2">
                Sign Up Now
              </button>
            </ul>
          </div>
        </div>
        {/* Drawer */}
        <div className=" lg:hidden ">
          <UDrawer isOpen={isOpens} setIsOpen={setIsOpen}>
            <div className=" flex flex-col gap-2 mt-[1rem]">
              <div className=" flex gap-5 px-10 py-5 hover:bg-gray-400 w-[15rem] rounded-r-md">
                <h1 className=" text-white font-bold text-xl ">Home</h1>
              </div>

              <div className=" flex gap-5 px-10 py-5 hover:bg-gray-400 w-[15rem] rounded-r-md">
                <h1 className=" text-white font-bold text-xl ">Login</h1>
              </div>

              <div className=" flex gap-5 px-10 py-5 hover:bg-green-600 w-[15rem] rounded-r-md">
                <h1 className=" text-green-500 hover:text-white font-bold text-xl ">
                  Sign Up Now
                </h1>
              </div>
            </div>
          </UDrawer>
        </div>
        {/* content */}
        <div className="  lg:ml-44 mt-40 p-5">
          <h1 className=" text-white text-3xl lg:text-5xl font-bold ">FAQ</h1>

          <p className="text-base mt-6 md:w-[30rem] text-[#FFFFE8]">
            {" "}
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsa
            laboriosam voluptates sed beatae?
          </p>
          <div className=" lg:ml-6 flex flex-col md:flex-row gap-5 lg:gap-[3rem] w-[100%]">
            
            
            <div className="md:w-full lg:w-[30%] bg-[#343434] shadow-md shadow-[#000000] mt-8 rounded-sm p-3 overflow-y-scroll  max-h-[35rem]">      
              <div className=" flex flex-col gap-5 p-2">
            
              <div className="flex justify-between">
                <div className="flex gap-5">
                  <input
                    id="default-checkbox"
                    type="checkbox"
                    value=""
                    className="w-4 h-4 text-[#9092B7] bg-[#9092B7] mt-1"
                  ></input>
                  <p className="text-[#FFFFE8]">
                    What is a proxy generator?
                  </p>
                </div>
                <img className="w-6 h-6" src={faqexpand} />
              </div>

              <div className="flex justify-between">
                <div className=" flex gap-5">
                <input
                    id="default-checkbox"
                    type="checkbox"
                    value=""
                    className="w-4 h-4 text-[#9092B7] bg-[#9092B7] mt-9"
                  ></input>
                  <p className="text-[#FFFFE8] w-[15rem]">
                    What is a proxy generator and how do i use it cause
                    this is a longer question to test the boundaries of this FAQ.
                  </p>
                </div>
                  <div>
                  <img className="w-6 h-6 mt-8" src={faqexpand} />
                  </div>
              </div>

              <div className="flex justify-between">
                <div className="flex gap-5">
                  <input
                    id="default-checkbox"
                    type="checkbox"
                    value=""
                    className="w-4 h-4 text-[#9092B7] bg-[#9092B7] mt-1"
                  ></input>
                  <p className="text-[#FFFFE8]">
                  Help me with my password?
                  </p>
                </div>
                <img className="w-6 h-6" src={faqexpand} />
              </div>

              <div className="flex justify-between">
                <div className="flex gap-5">
                  <input
                    id="default-checkbox"
                    type="checkbox"
                    value=""
                    className="w-4 h-4 text-[#9092B7] bg-[#9092B7] mt-1"
                  ></input>
                  <p className="text-[#FFFFE8]">
                  How do i use the internet?
                  </p>
                </div>
                <img className="w-6 h-6" src={faqexpand} />
              </div>

              <div className="flex justify-between">
                <div className="flex gap-5">
                  <input
                    id="default-checkbox"
                    type="checkbox"
                    value=""
                    className="w-4 h-4 text-[#9092B7] bg-[#9092B7] mt-1"
                  ></input>
                  <p className="text-[#FFFFE8]">
                    What is a proxy generator?
                  </p>
                </div>
                <img className="w-6 h-6" src={faqexpand} />
              </div>


              <div className="flex justify-between">
                <div className="flex gap-5">
                  <input
                    id="default-checkbox"
                    type="checkbox"
                    value=""
                    className="w-4 h-4 text-[#9092B7] bg-[#9092B7] mt-1"
                  ></input>
                  <p className="text-[#FFFFE8]">
                    What is a proxy generator?
                  </p>
                </div>
                <img className="w-6 h-6" src={faqexpand} />
              </div>

              <div className="flex justify-between">
                <div className="flex gap-5">
                  <input
                    id="default-checkbox"
                    type="checkbox"
                    value=""
                    className="w-4 h-4 text-[#9092B7] bg-[#9092B7] mt-1"
                  ></input>
                  <p className="text-[#FFFFE8]">
                    What is a proxy generator?
                  </p>
                </div>
                <img className="w-6 h-6" src={faqexpand} />
              </div>

              <div className="flex justify-between">
                <div className="flex gap-5">
                  <input
                    id="default-checkbox"
                    type="checkbox"
                    value=""
                    className="w-4 h-4 text-[#9092B7] bg-[#9092B7] mt-1"
                  ></input>
                  <p className="text-[#FFFFE8]">
                    What is a proxy generator?
                  </p>
                </div>
                <img className="w-6 h-6" src={faqexpand} />
              </div>

              <div className="flex justify-between">
                <div className="flex gap-5">
                  <input
                    id="default-checkbox"
                    type="checkbox"
                    value=""
                    className="w-4 h-4 text-[#9092B7] bg-[#9092B7] mt-1"
                  ></input>
                  <p className="text-[#FFFFE8]">
                    What is a proxy generator?
                  </p>
                </div>
                <img className="w-6 h-6" src={faqexpand} />
              </div>

              <div className="flex justify-between">
                <div className="flex gap-5">
                  <input
                    id="default-checkbox"
                    type="checkbox"
                    value=""
                    className="w-4 h-4 text-[#9092B7] bg-[#9092B7] mt-1"
                  ></input>
                  <p className="text-[#FFFFE8]">
                    What is a proxy generator?
                  </p>
                </div>
                <img className="w-6 h-6" src={faqexpand} />
              </div>

              <div className="flex justify-between">
                <div className="flex gap-5">
                  <input
                    id="default-checkbox"
                    type="checkbox"
                    value=""
                    className="w-4 h-4 text-[#9092B7] bg-[#9092B7] mt-1"
                  ></input>
                  <p className="text-[#FFFFE8]">
                    What is a proxy generator?
                  </p>
                </div>
                <img className="w-6 h-6" src={faqexpand} />
              </div>


              <div className="flex justify-between">
                <div className="flex gap-5">
                  <input
                    id="default-checkbox"
                    type="checkbox"
                    value=""
                    className="w-4 h-4 text-[#9092B7] bg-[#9092B7] mt-1"
                  ></input>
                  <p className="text-[#FFFFE8]">
                    What is a proxy generator?
                  </p>
                </div>
                <img className="w-6 h-6" src={faqexpand} />
              </div>

              <div className="flex justify-between">
                <div className="flex gap-5">
                  <input
                    id="default-checkbox"
                    type="checkbox"
                    value=""
                    className="w-4 h-4 text-[#9092B7] bg-[#9092B7] mt-1"
                  ></input>
                  <p className="text-[#FFFFE8]">
                    What is a proxy generator?
                  </p>
                </div>
                <img className="w-6 h-6" src={faqexpand} />
              </div>

              <div className="flex justify-between">
                <div className="flex gap-5">
                  <input
                    id="default-checkbox"
                    type="checkbox"
                    value=""
                    className="w-4 h-4 text-[#9092B7] bg-[#9092B7] mt-1"
                  ></input>
                  <p className="text-[#FFFFE8]">
                    What is a proxy generator?
                  </p>
                </div>
                <img className="w-6 h-6" src={faqexpand} />
              </div>

              <div className="flex justify-between">
                <div className="flex gap-5">
                  <input
                    id="default-checkbox"
                    type="checkbox"
                    value=""
                    className="w-4 h-4 text-[#9092B7] bg-[#9092B7] mt-1"
                  ></input>
                  <p className="text-[#FFFFE8]">
                    What is a proxy generator?
                  </p>
                </div>
                <img className="w-6 h-6" src={faqexpand} />
              </div>


              <div className="flex justify-between">
                <div className="flex gap-5">
                  <input
                    id="default-checkbox"
                    type="checkbox"
                    value=""
                    className="w-4 h-4 text-[#9092B7] bg-[#9092B7] mt-1"
                  ></input>
                  <p className="text-[#FFFFE8]">
                    What is a proxy generator?
                  </p>
                </div>
                <img className="w-6 h-6" src={faqexpand} />
              </div>


              <div className="flex justify-between">
                <div className="flex gap-5">
                  <input
                    id="default-checkbox"
                    type="checkbox"
                    value=""
                    className="w-4 h-4 text-[#9092B7] bg-[#9092B7] mt-1"
                  ></input>
                  <p className="text-[#FFFFE8]">
                    What is a proxy generator?
                  </p>
                </div>
                <img className="w-6 h-6" src={faqexpand} />
              </div>

              <div className="flex justify-between">
                <div className="flex gap-5">
                  <input
                    id="default-checkbox"
                    type="checkbox"
                    value=""
                    className="w-4 h-4 text-[#9092B7] bg-[#9092B7] mt-1"
                  ></input>
                  <p className="text-[#FFFFE8]">
                    What is a proxy generator?
                  </p>
                </div>
                <img className="w-6 h-6" src={faqexpand} />
              </div>


              <div className="flex justify-between">
                <div className="flex gap-5">
                  <input
                    id="default-checkbox"
                    type="checkbox"
                    value=""
                    className="w-4 h-4 text-[#9092B7] bg-[#9092B7] mt-1"
                  ></input>
                  <p className="text-[#FFFFE8]">
                    What is a proxy generator?
                  </p>
                </div>
                <img className="w-6 h-6" src={faqexpand} />
              </div>
             

              </div>

            </div>

            <div
              className="bg-[#343434] shadow-md shadow-[#000000] lg:mr-24 w-full lg:w-[47%] mt-8  rounded-md p-5"
            >
              <div className="text-white flex flex-col gap-20 ">
               <div className=" flex flex-col gap-7">
               <h3 className="md:text-lglg:text-xl font-semibold">
                  How do I use the internet?
                </h3>
                <p className=" text-sm lg:text-base">What is a proxy generator and how do i use it cause this is a
                longer question to test the boundaries of this FAQ entry and how
                it should look for dev.</p>
                
               <p className=" text-sm lg:text-base"> What is a proxy generator and how do i use it cause this is a
                longer question to test the boundaries of this FAQ entry and how
                it should look for dev.</p>
                
                <p className=" text-sm lg:text-base">What is a proxy generator and how do i use it cause this is a
                longer question to test the boundaries of this FAQ entry and how
                it should look for dev.</p>
               </div>
               <div className="mt-4 lg:mt-6">
               <h3 className="text-[#FFFFE8] text-lg lg:text-xl font-semibold">
                  Still need help?
                </h3>
                
                <p className=" text-sm lg:text-base">If you are logged in you can submit a support ticket to our
                customer service team.</p>
               </div>
              </div>

              <div className=" mt-8 text-center ">
              <button className=" bg-gray-100 text-black text-sm rounded-md w-[10rem] px-2 py-2">
            Go to Support
          </button>
              </div>
            </div>

          </div>
        </div>
        {/* footer */}
      <Footer/>
      </div>
    </div>
  );
}

export default FAQ;
